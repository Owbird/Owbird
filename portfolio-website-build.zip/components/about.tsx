'use client'

import { motion } from 'framer-motion'
import { Avatar } from '@/components/ui/avatar'

export function About() {
  return (
    <section id="about" className="py-24 px-6 bg-secondary/30">
      <div className="max-w-5xl mx-auto">
        <motion.div
          className="grid md:grid-cols-3 gap-12 items-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <motion.div
            className="md:col-span-2"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">About Me</h2>
            <div className="space-y-4 text-foreground/80 leading-relaxed">
              <p>
                I'm a technical founder and AI engineer focused on building scalable infrastructure for the African continent. 
                My expertise spans distributed systems, machine learning platforms, and real-time data processing.
              </p>
              <p>
                Over the past years, I've led the development of mission-critical systems handling millions of transactions, 
                mentored teams across multiple organizations, and contributed to open-source projects in the data infrastructure space.
              </p>
              <p>
                I'm passionate about creating technology that solves real problems and enables others to build faster and smarter.
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <div className="flex justify-center md:justify-end">
              <div className="relative w-48 h-48 rounded-2xl overflow-hidden border-2 border-accent/30">
                <div className="absolute inset-0 bg-gradient-to-br from-accent/20 to-transparent" />
                <Avatar className="w-full h-full rounded-2xl bg-accent/10" />
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
