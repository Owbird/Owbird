'use client'

import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ArrowRight } from 'lucide-react'

const projects = [
  {
    title: 'Distributed GPU Pooling System',
    description: 'Serverless GPU marketplace connecting ML engineers with distributed compute resources',
    tags: ['Python', 'Kubernetes', 'Go', 'gRPC'],
  },
  {
    title: 'Data Intelligence Platform',
    description: 'Real-time analytics and ML pipeline for high-volume data processing and insights',
    tags: ['Rust', 'Apache Kafka', 'PostgreSQL', 'React'],
  },
  {
    title: 'AI Career Mapping Tool',
    description: 'ML-powered system that matches professionals with optimal career trajectories',
    tags: ['TensorFlow', 'Node.js', 'Next.js', 'Vector DB'],
  },
  {
    title: 'Real-time Market Intelligence',
    description: 'Live market data aggregation and predictive analytics for trading platforms',
    tags: ['WebSockets', 'Pandas', 'FastAPI', 'Redis'],
  },
  {
    title: 'Data Quality Scoring Engine',
    description: 'Automated data validation and quality monitoring for enterprise data pipelines',
    tags: ['Python', 'Great Expectations', 'Airflow', 'Prometheus'],
  },
  {
    title: 'Serverless Go Framework',
    description: 'High-performance framework for building serverless applications with Go',
    tags: ['Go', 'AWS Lambda', 'Terraform', 'OpenTelemetry'],
  },
]

export function Projects() {
  return (
    <section id="projects" className="py-24 px-6 bg-secondary/30">
      <div className="max-w-6xl mx-auto">
        <motion.h2
          className="text-3xl md:text-4xl font-bold mb-16"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          Featured Projects
        </motion.h2>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              className="group relative bg-card border border-border rounded-2xl p-6 hover:border-accent/50 transition-all overflow-hidden"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -8, transition: { duration: 0.2 } }}
            >
              {/* Glow effect on hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-accent/0 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />

              <div className="relative z-10">
                <h3 className="text-xl font-bold mb-3 text-foreground">{project.title}</h3>
                <p className="text-foreground/70 mb-4 leading-relaxed">{project.description}</p>

                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="bg-secondary/50 text-foreground/80">
                      {tag}
                    </Badge>
                  ))}
                </div>

                <motion.button
                  className="inline-flex items-center gap-2 text-accent font-medium hover:gap-3 transition-all"
                  whileHover={{ x: 4 }}
                >
                  View Case Study
                  <ArrowRight className="h-4 w-4" />
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
