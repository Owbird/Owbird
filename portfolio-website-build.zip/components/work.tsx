'use client'

import { motion } from 'framer-motion'

const workItems = [
  {
    role: 'Founder & CTO',
    organization: 'IntelliCore Systems',
    impact: 'Led development of distributed GPU pooling platform serving 500+ ML engineers across Africa',
    year: '2023',
  },
  {
    role: 'Senior AI Engineer',
    organization: 'DataFlow Technologies',
    impact: 'Built real-time data processing pipeline handling 10M+ events/day with 99.99% uptime',
    year: '2022',
  },
  {
    role: 'ML Infrastructure Lead',
    organization: 'CloudScale Inc',
    impact: 'Designed and deployed serverless ML training platform supporting 50+ teams',
    year: '2021',
  },
  {
    role: 'Software Engineer',
    organization: 'TechStart Ventures',
    impact: 'Developed backend services and APIs for distributed systems, mentored 5 junior engineers',
    year: '2020',
  },
]

export function Work() {
  return (
    <section id="work" className="py-24 px-6">
      <div className="max-w-5xl mx-auto">
        <motion.h2
          className="text-3xl md:text-4xl font-bold mb-16"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          Work Experience
        </motion.h2>

        <div className="space-y-8">
          {workItems.map((item, index) => (
            <motion.div
              key={index}
              className="relative pl-6 border-l-2 border-accent/20 hover:border-accent/50 transition-all"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <div className="absolute left-[-9px] top-0 w-4 h-4 rounded-full bg-accent border-2 border-background" />

              <div className="pb-8">
                <div className="flex flex-col md:flex-row md:items-baseline md:justify-between mb-2 gap-2">
                  <h3 className="text-xl font-bold text-foreground">{item.role}</h3>
                  <span className="text-sm text-muted-foreground">{item.year}</span>
                </div>
                <p className="text-accent mb-3 font-medium">{item.organization}</p>
                <p className="text-foreground/70 leading-relaxed">{item.impact}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
