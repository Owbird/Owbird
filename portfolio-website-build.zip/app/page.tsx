import { Navbar } from '@/components/navbar'
import { Hero } from '@/components/hero'
import { About } from '@/components/about'
import { Work } from '@/components/work'
import { Projects } from '@/components/projects'
import { Writing } from '@/components/writing'
import { Contact } from '@/components/contact'
import { Footer } from '@/components/footer'

export default function Home() {
  return (
    <main className="bg-background text-foreground">
      <Navbar />
      <Hero />
      <About />
      <Work />
      <Projects />
      <Writing />
      <Contact />
      <Footer />
    </main>
  )
}
